# RCOS — Richcrest Creative Operating System

A single-page prompt builder for cinematic commercials and UGC product reviews.

## Files

- `index.html`
- `style.css`
- `script.js`

## GitHub Pages Setup

1. Create a new GitHub repository.
2. Upload these files to the root of the repo.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose:
   - Source: Deploy from a branch
   - Branch: main
   - Folder: /root
5. Save and open the GitHub Pages URL.

## What RCOS Does

RCOS helps assemble:
- Creative brief
- Content type
- Niche
- Emotion
- Story framework
- Camera language
- Lighting
- Motion / physics
- CTA
- Higgsfield-ready prompt
