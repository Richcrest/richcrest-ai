const form = document.getElementById("promptForm");
const generateBtn = document.getElementById("generateBtn");
const copyBtn = document.getElementById("copyBtn");
const output = document.getElementById("output");

const field = (id) => document.getElementById(id).value.trim();

const emotionMap = {
  Luxury: "premium, elegant, refined, quiet confidence, expensive visual restraint",
  Desire: "irresistible, crave-worthy, bold, sensory, visually tempting",
  Trust: "authentic, honest, transparent, natural, believable",
  Excitement: "fast, energetic, explosive, dynamic, high-impact",
  Comfort: "warm, cozy, soft, relaxed, familiar",
  Curiosity: "mysterious, unexpected, revealing, discovery-driven",
  Power: "dominant, athletic, intense, larger-than-life",
  Transformation: "before-to-after, growth, improvement, momentum",
  Urgency: "fast decision, limited-time energy, strong call-to-action"
};

const commercialStructure = `COMMERCIAL STRUCTURE
1. Hook: Open with the strongest visual frame immediately.
2. Build: Show the product, service, or experience in motion.
3. Payoff: Reveal the outcome or premium result.
4. CTA: End with one clear action.`;

const ugcStructure = `UGC REVIEW STRUCTURE
1. Hook: Start like a real creator with a direct opinion or discovery.
2. Problem: Explain what made the product useful or interesting.
3. Demo: Show the product being used naturally.
4. Reaction: Give a believable first-person response.
5. CTA: Recommend the viewer try, shop, book, or order.`;

function generatePrompt() {
  const projectName = field("projectName") || "Untitled RCOS Project";
  const contentType = field("contentType");
  const niche = field("niche");
  const subject = field("subject") || "[Add product or business]";
  const emotion = field("emotion");
  const story = field("story");
  const personality = field("personality");
  const environment = field("environment");
  const camera = field("camera");
  const lighting = field("lighting");
  const motion = field("motion");
  const platform = field("platform");
  const cta = field("cta") || "[Add CTA]";
  const notes = field("notes") || "No extra notes.";

  let typeLabel = "Cinematic Commercial";
  let structure = commercialStructure;

  if (contentType === "ugc") {
    typeLabel = "UGC Product Review";
    structure = ugcStructure;
  }

  if (contentType === "bundle") {
    typeLabel = "Commercial + UGC Bundle";
    structure = `${commercialStructure}\n\n${ugcStructure}`;
  }

  const psychology = emotionMap[emotion] || emotion;

  const prompt = `RCOS CREATIVE BRIEF

Project:
${projectName}

Content Type:
${typeLabel}

Niche:
${niche}

Hero Subject:
${subject}

Primary Emotion:
${emotion} — ${psychology}

Story Framework:
${story}

Brand Personality:
${personality}

Platform / Aspect Ratio:
${platform}

Environment:
${environment}

Camera Language:
${camera}

Lighting:
${lighting}

Motion + Physics:
${motion}

CTA:
${cta}

Extra Notes:
${notes}

${structure}


HIGGSFIELD-READY PROMPT

Create a ${platform.toLowerCase()} ${typeLabel.toLowerCase()} for ${subject}. The creative direction should feel ${emotion.toLowerCase()}, with a ${personality.toLowerCase()} brand personality. Set the scene in a ${environment.toLowerCase()}. Use ${camera.toLowerCase()} as the main camera language. Light the scene with ${lighting.toLowerCase()}. Add realistic motion details: ${motion.toLowerCase()}.

The story follows a ${story.toLowerCase()} structure. Make the first second visually powerful and easy to understand on a phone screen. Keep the subject as the clear hero of the frame. Use cinematic depth, clean composition, realistic texture, and intentional pacing. End on a polished final hero frame with readable on-screen text: "${cta}".

STYLE NOTES
- Concrete and sensory visual details.
- Motion should feel physically believable.
- One hero subject only.
- Clean phone-first composition.
- Premium commercial finish.
- Avoid cluttered text.
- Keep final CTA short and readable.`;

  output.textContent = prompt;
}

generateBtn.addEventListener("click", generatePrompt);

copyBtn.addEventListener("click", async () => {
  try {
    await navigator.clipboard.writeText(output.textContent);
    copyBtn.textContent = "Copied";
    setTimeout(() => (copyBtn.textContent = "Copy"), 1400);
  } catch (error) {
    copyBtn.textContent = "Select + Copy";
    setTimeout(() => (copyBtn.textContent = "Copy"), 1400);
  }
});
